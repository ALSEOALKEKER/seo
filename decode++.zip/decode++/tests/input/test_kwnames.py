def foo(x):
	print(x)
foo(x=1)
