def GEN_START():
    yield 0
