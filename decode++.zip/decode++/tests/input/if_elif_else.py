def test(msgtype, flags):
    if flags == 1:
        msgtype = 1
    elif flags == 2:
        msgtype = 2
    elif flags == 3:
        msgtype = 3
    return msgtype
